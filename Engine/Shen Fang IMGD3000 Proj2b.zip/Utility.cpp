//
//  Utility.cpp
//  IMGD3000 proj2a
//
//  Created by 方申 on 2/9/22.
//  Copyright © 2022 Shen Fang. All rights reserved.
//

#include "Vector.h"
#include <cmath>

namespace df{
bool positionIntersect(Vector p1, Vector p2){
    if (abs(p1.getX() - p2.getX())<=1 && abs(p1.getY() - p2.getY())<=1){
        return true;
    }
    return false;
}
}
