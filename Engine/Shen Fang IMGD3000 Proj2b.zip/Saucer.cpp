//
//  Saucer.cpp
//  IMGD3000 proj2a
//
//  Created by 方申 on 2/2/22.
//  Copyright © 2022 Shen Fang. All rights reserved.
//

//engine includes
#include "Saucer.h"
#include "LogManager.h"
#include "DisplayManager.h"
#include "EventStep.h"
#include "EventOut.h"
#include "EventCollision.h"
#include "Vector.h"
#include "Color.h"




Saucer::Saucer() {
    setType("Saucer");
    df::Vector position(5,getId());
    df::Vector velocity(0.2,0);
    setSolidness(df::HARD);
    setPosition(position);
    setVelocity(velocity);
}


int Saucer::eventHandler(const df::Event *p_e) {
    LM.writeLog("received an event");
    if (p_e -> getType() == df::STEP_EVENT) {
        LM.writeLog("type is step");
        return 1;
    }
    if (p_e -> getType() == df::COLLISION_EVENT) {
        LM.writeLog("type is collision");
        return 1;
    }
    if (p_e -> getType() == df::OUT_EVENT){
        LM.writeLog("Saucer out of bound");
    }
    return 0;
}

int Saucer::draw(){
    DM.drawCh(getPosition(), 'o', df::WHITE);
}

