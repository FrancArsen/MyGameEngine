//
//  EventOut.cpp
//  IMGD3000 proj2a
//
//  Created by 方申 on 2/9/22.
//  Copyright © 2022 Shen Fang. All rights reserved.
//

#include "EventOut.h"

namespace df{

EventOut::EventOut(){
    setType(OUT_EVENT);
}
}
