
Shen Fang 
sfang3@wpi.edu

Platform: Mac

This is a prototype of dragon fly game engine\
With following features:\
Creating objects\
Adding/removing objects from game world\
Run a game with basic functions and managers\
Game loop with basic functions\
Writing logs to text\
Rendering out window
Draw characters
kenetics
Keyboard/mouse inputs
}